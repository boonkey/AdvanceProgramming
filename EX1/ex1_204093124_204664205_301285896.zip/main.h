#pragma once
#include <iostream>
#include <string>
#include "data_types.h"
#include "Player.cpp"
#include "fileParsing.h"
#include "utilities.h"


// ================= Global Variables ================
Configuration config;


