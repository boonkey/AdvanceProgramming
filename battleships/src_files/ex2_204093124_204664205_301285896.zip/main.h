#pragma once
#include "Game.h"
#include "IBattleshipGameAlgo.h"

typedef IBattleshipGameAlgo*(*GetAlgo)();